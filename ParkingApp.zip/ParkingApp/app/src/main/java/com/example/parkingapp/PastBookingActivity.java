package com.example.parkingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class PastBookingActivity extends AppCompatActivity {

    private ListView allBookings_LV;

    private ArrayList<String> all_bookings_list;
    private HashMap<String, JSONObject> small_to_all_bookings_map;
    private ArrayAdapter<String> all_bookings_adapter;
    private String auth_token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_past_booking);

        auth_token = getIntent().getStringExtra("auth_token");

        all_bookings_list = new ArrayList<>();
        small_to_all_bookings_map = new HashMap<>();

        postAllBookingDetailsRequest();

        allBookings_LV = (ListView) findViewById(R.id.pastBookings_LV);
        all_bookings_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, all_bookings_list);
        allBookings_LV.setAdapter(all_bookings_adapter);
        allBookings_LV.setOnItemClickListener(mDeviceClickListener);
    }

    // All Bookings Fetch Functions ----- START
    private void postAllBookingDetailsRequest() {
        RequestQueue queue = Volley.newRequestQueue(this);
        final String url = getString(R.string.serverURL) + getString(R.string.pastBookingPath);
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseAllBookingDetailsResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error.Response" + String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("auth_token", auth_token);
                return params;
            }
        };
        queue.add(postRequest);
    }

    private void parseAllBookingDetailsResponse(String response) {
        String response_status, response_message, response_all_bookings;
        try {
            JSONObject response_json_obj = new JSONObject(response);
            response_message = response_json_obj.getString("message");
            response_status = response_json_obj.getString("status");
            if (response_status.equals("opOK")) {
                Toast.makeText(this, "Fetching all Parking details", Toast.LENGTH_SHORT).show();
                response_all_bookings = response_json_obj.getString("pastBookings");
                parseAllBookingArray(response_all_bookings);
            } else {
                Toast.makeText(this, "Error Message: " + response_message, Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            Toast.makeText(this, "JSONParseException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void parseAllBookingArray(String response_all_bookings) {
        try {
            String lot_name, booking_start_date, booking_end_date, spot_name;

            all_bookings_list.clear();

            JSONArray allBookingsArray = new JSONArray(response_all_bookings);
            if (allBookingsArray.length() == 0){
                all_bookings_list.add("You have never made any bookings.");
            } else {
                for (int i = 0; i < allBookingsArray.length(); i++) {
                    JSONObject booking_obj = allBookingsArray.getJSONObject(i);
                    spot_name = new JSONObject(booking_obj.getString("spot")).getString("name");
                    lot_name = new JSONObject(booking_obj.getString("lot")).getString("name");
                    booking_start_date =  FormatDateToDisplay(booking_obj.getString("dateTimeOfBooking"));
                    if (booking_obj.has("dateTimeOfExit"))
                        booking_end_date =  FormatDateToDisplay(booking_obj.getString("dateTimeOfExit"));
                    else
                        booking_end_date = "Booking not stopped.";

                    String add_string = "";
                    add_string += "Booking No.: " + Integer.toString(i+1) + "\n";
                    add_string += "Spot name: " + spot_name + "\n";
                    add_string += "Lot Name: " + lot_name + "\n";
                    add_string += "Booking Start Time: " + booking_start_date + "\n";
                    add_string += "Booking End Time: " + booking_end_date;

                    all_bookings_list.add(add_string);
                    small_to_all_bookings_map.put(add_string, booking_obj);
                }
            }
            allBookings_LV.setAdapter(all_bookings_adapter);
        } catch (JSONException e) {
            Toast.makeText(this, "JSONParseError: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "AllBookingDetailsParseException:" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public String FormatDateToDisplay(String iso_date){
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        SimpleDateFormat format2 = new SimpleDateFormat("E, dd-MMM-yyyy, HH:mm:ss");
        Date temp_date = null;
        try {
            temp_date = format1.parse(iso_date);
            return format2.format(temp_date);
        } catch (ParseException e) {
            return "DateParseError: " + e.getMessage();
        }
    }

    // All Bookings Fetch Functions ----- END

    // ItemListener on the ListView
    private AdapterView.OnItemClickListener mDeviceClickListener = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> av, View v, int arg2, long arg3) {
            String small_descp = ((TextView) v).getText().toString();
            JSONObject to_display_obj = small_to_all_bookings_map.get(small_descp);

            Intent toDisplayBooking = new Intent(PastBookingActivity.this, DisplayBookingActivity.class);
            toDisplayBooking.putExtra("auth_token", auth_token);
            toDisplayBooking.putExtra("booking_obj", to_display_obj.toString());
            startActivity(toDisplayBooking);
        }
    };
}
