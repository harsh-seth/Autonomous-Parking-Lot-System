package com.example.parkingapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class LoginFragment extends Fragment {
    EditText username_et;
    EditText password_et;
    Button login_bt;

    String username;
    String password;

    // All the parameters that can be obtained from response to the server
    // Response String contains message, username, auth_token, status (All String), isAdmin (bool)
    String response_message;
    String response_auth_token;
    String response_username;
    String response_status;
    // Boolean response_isAdmin;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Intent fromMainIntent = getActivity().getIntent();
        View rootView = inflater.inflate(R.layout.fragment_login, null);
        username_et = (EditText) rootView.findViewById(R.id.et_username);
        password_et = (EditText) rootView.findViewById(R.id.et_password);
        login_bt = (Button) rootView.findViewById(R.id.bt_login);

        login_bt.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                username = username_et.getText().toString();
                password = password_et.getText().toString();

                if (validate_login_user(username, password)) {
                    makeLoginPostRequest();
                } else {
                    Toast.makeText(getActivity(), "Invalid format of username or password", Toast.LENGTH_SHORT).show();
                }
            }

        });

        return rootView;
    }

    private boolean validate_login_user(String username, String password) {
        // Validate from server about the authenticity of user and
        // For valid user, return success
        // Else return the string regarding error
        if (username.matches(getString(R.string.username_regexp)) && password.matches(getString(R.string.password_regexp))){
            return true;
        } else
            return false;
    }

    public void successLogin(String username, String auth_token, String message){
        // Show successful Login message
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();

        // Store the auth token in the file
        writeToAuthFile(auth_token, username);

        // Goto next Home activity
        Intent i = new Intent(getActivity(),HomeActivity.class);
        i.putExtra("username", username);
        i.putExtra("auth_token", auth_token);
        startActivity(i);
        getActivity().finish();
    }

    private void parseLoginResponse(String response) {
        try {
            JSONObject response_json_obj = new JSONObject(response);
            response_status = response_json_obj.getString("status");
            response_message = response_json_obj.getString("message");
            if (response_status.equals("loginOK")){
                response_auth_token = response_json_obj.getString("auth_token");
                response_username = response_json_obj.getString("username");
                successLogin(response_username, response_auth_token, response_message);
            } else if (response_status.equals("invalidPassword") || response_status.equals("invalidUser")) {
                Toast.makeText(getActivity(), response_message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Unknown Error in Login Fragment", Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            Toast.makeText(getActivity(), "JSON Parse Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void makeLoginPostRequest(){
        RequestQueue queue = Volley.newRequestQueue(getActivity());

        final String url = getString(R.string.serverURL) + getString(R.string.loginPath);
        // Toast.makeText(getActivity(), "URL: " + url, Toast.LENGTH_SHORT).show();

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        // Log.d("Post Response: ", response);
                        parseLoginResponse(response);
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error.Response", String.valueOf(error));
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }
        };
        queue.add(postRequest);
    }

    public void writeToAuthFile(String auth_token, String username){
        try {
            File AuthTokenFile = new File(getActivity().getFilesDir() + "/" + getString(R.string.authFileName));
            PrintWriter writer = new PrintWriter(AuthTokenFile);
            writer.println(auth_token);
            writer.println(username);

            writer.flush();
            writer.close();

            Toast.makeText(getActivity(), "Auth Token saved to device", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getActivity(), "AuthTokenWriteException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}