package com.example.parkingapp;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class HomeActivity extends AppCompatActivity {

    ListView parking_details_LV;
    ImageButton refreshCurrentParking_BT, pastBooking_BT, setting_BT, toggleParking_BT;
    ArrayList<String> current_bookings_list;
    String auth_token, username;

    private final static int REQUEST_ENABLE_BT = 1;

    public static Handler closeHomeHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent i = getIntent();
        auth_token = i.getStringExtra("auth_token");
        username = i.getStringExtra("username");


        parking_details_LV= (ListView) findViewById(R.id.parking_deatils_listview);
        toggleParking_BT = (ImageButton) findViewById(R.id.BookParking_BT);
        refreshCurrentParking_BT = (ImageButton) findViewById(R.id.refreshCurrentBooking_BT);
        setting_BT = (ImageButton) findViewById(R.id.setting_BT);
        pastBooking_BT = (ImageButton) findViewById(R.id.pastBooking_BT);

        current_bookings_list = new ArrayList<String>();

        if(!i.hasExtra("DontRefreshDontRefresh"))
            refreshCurrentBookingList();

        closeHomeHandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                switch(msg.what) {
                    case 0:
                        finish();
                        break;
                }
                return true;
            }
        });

        toggleParking_BT.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // Depending on the state of parking
                // If user is already parked, the button wil show de-issue parking
                // on Click will make a request to de-issue a parking
                // Else, button will show Issue parking and
                // on click will issue a parking to the user by making a request to the server
                issueParkingByBluetooth();
                finish();
            }

        });

        refreshCurrentParking_BT.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                refreshCurrentBookingList();
            }

        });

        setting_BT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toSettingActivity = new Intent(HomeActivity.this, SettingsActivity.class);
                toSettingActivity.putExtra("auth_token", auth_token);
                startActivity(toSettingActivity);

            }
        });

        pastBooking_BT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toPastBookingActivity = new Intent(HomeActivity.this, PastBookingActivity.class);
                toPastBookingActivity.putExtra("auth_token", auth_token);
                startActivity(toPastBookingActivity);
            }
        });
    }


    // Refresh Current Parking(s) ----- START
    public void refreshCurrentBookingList() {
        postCurrentBookingDetailsRequest();
    }

    public void postCurrentBookingDetailsRequest() {
        RequestQueue queue = Volley.newRequestQueue(this);
        final String url = getString(R.string.serverURL) + getString(R.string.currentBookingsPath);
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Log.d("Post Response: ", response);
                        parseCurrentBookingDetailsResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(HomeActivity.this, "Error.Response" + String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("auth_token", auth_token);
                return params;
            }
        };
        queue.add(postRequest);
    }

    private void parseCurrentBookingDetailsResponse(String response) {
        try {
            String response_message, response_status, response_current_bookings;

            JSONObject response_json_obj = new JSONObject(response);
            response_message = response_json_obj.getString("message");
            response_status = response_json_obj.getString("status");
            if (response_status.equals("opOK")) {
                Toast.makeText(this, "Refreshing Parking details", Toast.LENGTH_SHORT).show();
                response_current_bookings = response_json_obj.getString("currentBookings");
                parseCurrentBookingArray(response_current_bookings);
            } else if (response_status.equals("privError")) {
                Toast.makeText(this, "Invalid Auth Error: " + response_message, Toast.LENGTH_SHORT).show();
                invalidAuthTokenDeletion();
            } else {
                Toast.makeText(this, "Message: " + response_message, Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            Toast.makeText(this, "JSONParseException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void parseCurrentBookingArray(String response_current_bookings) {
        try {
            String lot_name, booking_start_date, spot_name;

            current_bookings_list.clear();

            JSONArray currentBookingsArray = new JSONArray(response_current_bookings);
            if (currentBookingsArray.length() == 0){
                current_bookings_list.add("No Current Bookings yet. Go Book a slot now!!!");
            } else {
                for (int i = 0; i < currentBookingsArray.length(); i++) {
                    JSONObject booking_obj = currentBookingsArray.getJSONObject(i);
                    spot_name = new JSONObject(booking_obj.getString("spot")).getString("name");
                    lot_name = new JSONObject(booking_obj.getString("lot")).getString("name");
                    booking_start_date =  FormatDateToDisplay(booking_obj.getString("dateTimeOfBooking"));

                    String add_string = "";
                    add_string += "Booking No: " + Integer.toString(i+1) + "\n";
                    add_string += "Spot name: " + spot_name + "\n";
                    add_string += "Lot Name: " + lot_name + "\n";
                    add_string += "Booking Time: " + booking_start_date + "\n";

                    current_bookings_list.add(add_string);
                }
            }

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, current_bookings_list);
            parking_details_LV.setAdapter(arrayAdapter);
        } catch (JSONException e) {
            Toast.makeText(this, "JSONParseError: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "BookingDetailsParseException:" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    public String FormatDateToDisplay(String iso_date){
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        SimpleDateFormat format2 = new SimpleDateFormat("E, dd-MMM-yyyy, HH:mm:ss");
        Date temp_date = null;
        try {
            temp_date = format1.parse(iso_date);
            return format2.format(temp_date);
        } catch (ParseException e) {
            return "DateParseError: " + e.getMessage();
        }
    }
    // Refresh Current Parking(s) ----- END

    // Auth File invalid  Function(s) ----- START
    public void invalidAuthTokenDeletion() {
        File auth_file = new File(this.getFilesDir() + "/" + getString(R.string.authFileName));
        if (auth_file.delete()){
            Toast.makeText(this, "Auth File was invalid. Redirecting to Login Page", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Auth File does not exists. Please login again.", Toast.LENGTH_SHORT).show();
        }
        Intent toLoginRegisterActivity = new Intent(HomeActivity.this, Login_Register_Activity.class);
        startActivity(toLoginRegisterActivity);
        finish();
    }

    // Auth File invalid Function(s) ----- END

    // Issue Parking Function(s) ----- START
    public void issueParkingByBluetooth() {
        Intent i = new Intent(HomeActivity.this, BluettoothListActivity.class);
        i.putExtra("auth_token", auth_token);
        startActivity(i);
//        finish();
    }

    // Issue Parking Function(s) ----- END
}

