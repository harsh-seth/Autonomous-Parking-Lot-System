package com.example.parkingapp;

import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;
import android.app.Fragment;
import android.app.FragmentManager;

import java.io.File;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    String auth_token, username;
    Intent toNextActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        readFromAuthFile();

        if (auth_token == null || username == null){
             toNextActivity = new Intent(MainActivity.this, Login_Register_Activity.class);
        } else {
            toNextActivity = new Intent(MainActivity.this, HomeActivity.class);
            toNextActivity.putExtra("auth_token", auth_token);
            toNextActivity.putExtra("username", username);
        }
        startActivity(toNextActivity);
        finish();

    }

    public void readFromAuthFile() {
        try {
            File authTokenFile = new File(this.getFilesDir() + "/" + getString(R.string.authFileName));
            if (authTokenFile.length() == 0) {
                auth_token = null;
                username = null;
            } else {
                Scanner reader = new Scanner(authTokenFile);
                while(reader.hasNextLine()){
                    auth_token = reader.nextLine();
                    username = reader.nextLine();
                }
                reader.close();
                Toast.makeText(getBaseContext(), "AuthFile read. Redirecting to Home Activity", Toast.LENGTH_LONG).show();
            }
        } catch(Exception e){
            Toast.makeText(this, "AuthFileReadException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            auth_token = null;
            username = null;
        }
    }
}
