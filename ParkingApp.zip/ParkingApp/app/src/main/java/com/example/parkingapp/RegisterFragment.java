package com.example.parkingapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterFragment extends Fragment {

    EditText username_et;
    EditText name_et;
    EditText phone_no_et;
    EditText password_et;
    EditText reenter_password_et;
    Button register_bt;

    String username, phone_no, name, password, confirm_password;
    private String response_status, response_message;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_register, null);
        username_et = (EditText) rootView.findViewById(R.id.et_username);
        name_et = (EditText) rootView.findViewById(R.id.et_name);
        phone_no_et = (EditText) rootView.findViewById(R.id.et_phone_no);
        password_et = (EditText) rootView.findViewById(R.id.et_password);
        reenter_password_et = (EditText) rootView.findViewById(R.id.et_reenter_password);
        register_bt = (Button) rootView.findViewById(R.id.bt_register);

        register_bt.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                username = username_et.getText().toString();
                name = name_et.getText().toString();
                phone_no = phone_no_et.getText().toString();
                password = password_et.getText().toString();
                confirm_password = reenter_password_et.getText().toString();

                if (validateRegisterUser(username, phone_no, name, password, confirm_password))
                    postRegisterRequest();
            }

        });

        return rootView;
    }

    private boolean validateRegisterUser(String username, String phone_no, String name, String password, String confirm_password) {
        // Send a request to server to register a user and get response string accordingly
        // If user is registered, return 'success'
        // Else return appropriate error string

        if (username.matches(getString(R.string.username_regexp))
        ||  name.matches(getString(R.string.name_regexp))
        ||  phone_no.matches(getString(R.string.phoneno_regexp))
        ||  password.matches(getString(R.string.password_regexp))) {
            if (password.equals(confirm_password))
                return true;
            else{
                Toast.makeText(getActivity(), "Passwords does not match.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        else{
            Toast.makeText(getActivity(), "Validations are failed.", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public void postRegisterRequest(){
        RequestQueue queue = Volley.newRequestQueue(getActivity());

        final String url = getString(R.string.serverURL) + getString(R.string.registerPath);
        // Toast.makeText(getActivity(), url, Toast.LENGTH_SHORT).show();

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        parseRegisterResponse(response);
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "RegisterRequestError: " + String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> register_params = new HashMap<String, String>();
                register_params.put("username", username);
                register_params.put("name", name);
                register_params.put("phone_no", phone_no);
                register_params.put("password", password);
                return register_params;
            }
        };
        queue.add(postRequest);
    }

    private void parseRegisterResponse(String response) {
        try {
            JSONObject response_json_obj = new JSONObject(response);
            response_status = response_json_obj.getString("status");
            response_message = response_json_obj.getString("message");
            if (response_status.equals("signupOK")){
                successRegister(response_message);
            } else if (response_status.equals("userTaken") || response_status.equals("invalidParams")) {
                Toast.makeText(getActivity(), response_message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "Unknown Error in Register Fragment", Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            Toast.makeText(getActivity(), "JSONParseException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void successRegister(String message) {
        Toast.makeText(getActivity(), message + ". Proceed to Log In.", Toast.LENGTH_SHORT).show();
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, new LoginFragment()).addToBackStack(null).commit();


    }
}