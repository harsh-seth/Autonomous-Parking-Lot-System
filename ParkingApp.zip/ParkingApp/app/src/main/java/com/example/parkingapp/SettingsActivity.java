package com.example.parkingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class SettingsActivity extends AppCompatActivity {

    EditText currentPassword_ET, newPassword_ET, newConfirmPassword_ET;
    Button changePassword_BT, logoutUser_BT, deregisterUser_BT;
    String auth_token;
    String current_password, new_password, new_confirm_password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        currentPassword_ET = (EditText) findViewById(R.id.currentPassword_ET);
        newPassword_ET = (EditText) findViewById(R.id.newPassword_ET);
        newConfirmPassword_ET = (EditText) findViewById(R.id.newConfirmPassword_ET);

        changePassword_BT = (Button) findViewById(R.id.changePassword_BT);
        logoutUser_BT = (Button) findViewById(R.id.logoutUser_BT);
        deregisterUser_BT = (Button) findViewById(R.id.deregister_BT);

        auth_token = getIntent().getStringExtra("auth_token");

        changePassword_BT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                current_password = currentPassword_ET.getText().toString();
                new_password = newPassword_ET.getText().toString();
                new_confirm_password = newConfirmPassword_ET.getText().toString();
                
                if (validatePasswords())
                    postChangePasswordRequest();
            }
        });

        logoutUser_BT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postLogoutUserRequest();
                authFileDeletion();

                Intent toLoginRegisterActivity = new Intent(SettingsActivity.this, Login_Register_Activity.class);
                HomeActivity.closeHomeHandler.sendEmptyMessage(0);
                startActivity(toLoginRegisterActivity);
                finish();
            }
        });

        deregisterUser_BT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postDeregisterUserRequest();
                authFileDeletion();

                Intent toLoginRegisterActivity = new Intent(SettingsActivity.this, Login_Register_Activity.class);
                toLoginRegisterActivity.putExtra("RegisterTask", "RegisterFragment");
                HomeActivity.closeHomeHandler.sendEmptyMessage(0);
                startActivity(toLoginRegisterActivity);
                finish();
            }
        });

    }

    // Change User Password Functions ----- START

    private void postChangePasswordRequest() {
        RequestQueue queue = Volley.newRequestQueue(this);

        final String url = getString(R.string.serverURL) + getString(R.string.changePasswordPath);
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseChangePasswordResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("changePasswordError:", String.valueOf(error));
                        Toast.makeText(SettingsActivity.this, "changePasswordRequestError: " + String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("auth_token", auth_token);
                params.put("newPassword", new_password);
                return params;
            }
        };
        queue.add(postRequest);
    }

    private void parseChangePasswordResponse(String response) {
        try {
            String response_status, response_message;

            JSONObject response_json_obj = new JSONObject(response);
            response_status = response_json_obj.getString("status");
            response_message = response_json_obj.getString("message");

            if (response_status.equals("pwChangedOK")){
                Toast.makeText(this, response_message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "ChangePasswordError: " + response_message, Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            Toast.makeText(this, "JSONParseException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validatePasswords() {
        if (
                current_password.matches(getString(R.string.password_regexp)) &&
                        new_password.matches(getString(R.string.password_regexp)) &&
                        new_confirm_password.matches(getString(R.string.password_regexp))
        ) {
            if (new_password.equals(new_confirm_password)){
                return true;
            }
            else {
                Toast.makeText(this, "New Password don't match", Toast.LENGTH_SHORT).show();
                return false;
            }
        } else {
            Toast.makeText(this, "Invalid Password formats", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    // Change User Password Functions ----- END

    // Logout User Functions ----- START
    private void postLogoutUserRequest() {
        RequestQueue queue = Volley.newRequestQueue(this);

        final String url = getString(R.string.serverURL) + getString(R.string.logoutUserPath);
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseLogoutUserResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("LogoutUserError:", String.valueOf(error));
                        Toast.makeText(SettingsActivity.this, "LogoutUserRequestError: " + String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("auth_token", auth_token);
                return params;
            }
        };
        queue.add(postRequest);
    }

    private void parseLogoutUserResponse(String response) {
        try {
            String response_status, response_message;

            JSONObject response_json_obj = new JSONObject(response);
            response_status = response_json_obj.getString("status");
            response_message = response_json_obj.getString("message");

            if (response_status.equals("logoutOK")){
                Toast.makeText(this, response_message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "LogoutUserResponseError: " + response_message, Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            Toast.makeText(this, "JSONParseException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    // Logout User Functions ----- END
    // Deregister User Functions ----- START

    private void postDeregisterUserRequest() {
        RequestQueue queue = Volley.newRequestQueue(this);

        final String url = getString(R.string.serverURL) + getString(R.string.deregisterUserPath);
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseDeregisterUserResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("DeregisterUserError:", String.valueOf(error));
                        Toast.makeText(SettingsActivity.this, "DeregisterUserError: " + String.valueOf(error), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("auth_token", auth_token);
                return params;
            }
        };
        queue.add(postRequest);
    }

    private void parseDeregisterUserResponse(String response) {
        try {
            String response_status, response_message;

            JSONObject response_json_obj = new JSONObject(response);
            response_status = response_json_obj.getString("status");
            response_message = response_json_obj.getString("message");

            if (response_status.equals("deregisterOK")){
                Toast.makeText(this, response_message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "DeregisterUserResponseError: " + response_message, Toast.LENGTH_SHORT).show();
            }

        } catch (JSONException e) {
            Toast.makeText(this, "JSONParseException: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // Deregister User Functions ----- END

    // Auth File Deletion Function (Used in Logout and Deregister)

    private void authFileDeletion() {
        File auth_file = new File(this.getFilesDir() + "/" + getString(R.string.authFileName));
        if (auth_file.delete()){
            Toast.makeText(this, "Auth File was successfully deleted.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Auth File didn't exist. Please login again anyway.", Toast.LENGTH_SHORT).show();
        }
    }

}
