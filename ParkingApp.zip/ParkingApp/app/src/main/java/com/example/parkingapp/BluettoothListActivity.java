package com.example.parkingapp;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Set;

public class BluettoothListActivity extends AppCompatActivity {

    TextView DisplayBox_TV;
    ListView pairedDevices_LV;

    String auth_token;
    public static String EXTRA_DEVICE_ADDRESS = "device_address";
    ArrayList<String> device_list = new ArrayList<>();
    private BluetoothAdapter mBtAdapter;
    private ArrayAdapter<String> mPairedDevicesArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluettooth_list);

        DisplayBox_TV = findViewById(R.id.displayBox_TV);
        pairedDevices_LV = findViewById(R.id.pairedDevices_LV);

        auth_token = getIntent().getStringExtra("auth_token");
    }

    @Override
    protected void onResume() {
        super.onResume();

        checkBTState();

        DisplayBox_TV = (TextView) findViewById(R.id.displayBox_TV);
        DisplayBox_TV.setTextSize(20);
        DisplayBox_TV.setText(" ");

        mPairedDevicesArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, device_list);
        pairedDevices_LV.setAdapter(mPairedDevicesArrayAdapter);
        pairedDevices_LV.setOnItemClickListener(mDeviceClickListener);

        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        // Get a set of currently paired devices and append to 'pairedDevices'
        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();

        // Add previosuly paired devices to the array
        if (pairedDevices.size() > 0) {
            device_list.clear();
            for (BluetoothDevice device : pairedDevices) {
                device_list.add(device.getName() + "\n" + device.getAddress());
            }
        } else {
            String noDevices = getResources().getText(R.string.none_paired).toString();
            Toast.makeText(this, noDevices, Toast.LENGTH_SHORT).show();
        }
    }

    private AdapterView.OnItemClickListener mDeviceClickListener = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> av, View v, int arg2, long arg3) {
            // Get the device MAC address, which is the last 17 chars in the View
            String info = ((TextView) v).getText().toString();
            String address = info.substring(info.length() - 17);

            DisplayBox_TV.setText("Connecting to address: " + address);

            // Make an intent to start next activity while taking an extra which is the MAC address.
            Intent i = new Intent(BluettoothListActivity.this, BluetoothConnectActivity.class);
            i.putExtra("EXTRA_DEVICE_ADDRESS", address);
            i.putExtra("auth_token", auth_token);
            startActivity(i);
            finish();

        }
    };

    private void checkBTState() {
        mBtAdapter=BluetoothAdapter.getDefaultAdapter(); // CHECK THIS OUT THAT IT WORKS!!!
        if(mBtAdapter==null) {
            Toast.makeText(getBaseContext(), "Device does not support Bluetooth", Toast.LENGTH_SHORT).show();
        } else {
            if (mBtAdapter.isEnabled()) {
                Log.d("BluetoothListActivity", "...Bluetooth ON...");
                Toast.makeText(this, "BluetoothListActivity using Bluetooth", Toast.LENGTH_SHORT).show();
            } else {
                //Prompt user to turn on Bluetooth
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);

            }
        }
    }
}
