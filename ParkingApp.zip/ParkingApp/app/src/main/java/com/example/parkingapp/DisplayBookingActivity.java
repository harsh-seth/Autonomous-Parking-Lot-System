package com.example.parkingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class DisplayBookingActivity extends AppCompatActivity {

    String auth_token, display_obj_string;
    ListView displayDetails_LV;

    ArrayList<String> booking_details_list;
    ArrayAdapter<String> booking_details_adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_booking);

        booking_details_list = new ArrayList<>();

        displayDetails_LV = (ListView) findViewById(R.id.bookingDetails_LV);
        booking_details_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, booking_details_list);

        Intent i = getIntent();
        auth_token = i.getStringExtra("auth_token");
        display_obj_string = i.getStringExtra("booking_obj");

        parseAndDisplayBooking();
    }

    private void parseAndDisplayBooking() {
        try {
            String lot_name, lot_location;
            String spot_name, spot_size;
            String booking_start_date, booking_end_date;

            booking_details_list.clear();

            JSONObject booking_obj = new JSONObject(display_obj_string);
            lot_name = booking_obj.getJSONObject("lot").getString("name");
            lot_location = booking_obj.getJSONObject("lot").getString("location");

            spot_name = booking_obj.getJSONObject("spot").getString("name");
            spot_size = booking_obj.getJSONObject("spot").getString("size");

            booking_start_date = booking_obj.getString("dateTimeOfBooking");
            if (booking_obj.has("dateTimeOfExit"))
                booking_end_date = booking_obj.getString("dateTimeOfExit");
            else
                booking_end_date = "Booking not finished yet.";

            booking_details_list.add("Lot Name: " + lot_name);
            booking_details_list.add("Lot Location: " + lot_location);
            booking_details_list.add("Spot Name: " + spot_name);
            booking_details_list.add("Spot Size: " + spot_size);
            booking_details_list.add("Booking Start Date: " + booking_start_date);
            booking_details_list.add("Booking End Date: " + booking_end_date);
            displayDetails_LV.setAdapter(booking_details_adapter);
        } catch (JSONException e) {
            Toast.makeText(this, "BookingObjParseError: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    public String FormatDateToDisplay(String iso_date){
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        SimpleDateFormat format2 = new SimpleDateFormat("E, dd-MMM-yyyy, HH:mm:ss");
        Date temp_date = null;
        try {
            temp_date = format1.parse(iso_date);
            return format2.format(temp_date);
        } catch (ParseException e) {
            return "DateParseError: " + e.getMessage();
        }
    }

}
